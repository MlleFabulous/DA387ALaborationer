package com.example.ericgrevillius.p4pathfinder;

public interface StepChangeListener {
    void update();
}
